-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: VirCreds
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Audit`
--

DROP TABLE IF EXISTS `Audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `User` varchar(150) DEFAULT NULL,
  `Cust` varchar(150) DEFAULT NULL,
  `Action` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit`
--

LOCK TABLES `Audit` WRITE;
/*!40000 ALTER TABLE `Audit` DISABLE KEYS */;
INSERT INTO `Audit` VALUES (1,'2012-12-08 14:08:46','ben','',11),(2,'2012-12-08 14:39:39','ben','',11),(3,'2012-12-08 15:46:28','ben','',11),(4,'2012-12-08 15:51:26','ben','12',15),(5,'2012-12-08 15:51:41','ben','20',3),(6,'2012-12-08 15:52:22','ben','',11),(7,'2012-12-08 15:52:32','ben','20',5),(8,'2012-12-08 15:52:58','ben','20',5),(9,'2012-12-08 15:53:10','ben','11',7),(10,'2012-12-08 15:53:16','ben','20',5),(11,'2012-12-08 15:53:54','ben','20',5),(12,'2012-12-08 15:55:05','ben','20',5),(13,'2012-12-08 16:31:41','ben','',11),(14,'2012-12-08 16:35:48','ben','',12),(15,'2012-12-08 16:36:25','ben','',11),(16,'2012-12-08 16:36:38','ben','',12),(17,'2012-12-08 16:37:10','ben','',11),(18,'2012-12-08 16:38:34','ben','',12),(19,'2012-12-08 16:40:00','ben','',11),(20,'2012-12-08 16:40:36','ben','',12),(21,'2012-12-08 16:41:21','ben','',11),(22,'2012-12-08 16:42:01','ben','',12),(23,'2012-12-08 17:12:41','ben','',11),(24,'2012-12-08 17:12:46','ben','20',5),(25,'2012-12-08 17:13:17','ben','',11),(26,'2012-12-08 17:20:52','ben','20',5),(27,'2012-12-08 17:20:55','ben','20',5),(28,'2012-12-08 17:38:37','ben','',11),(29,'2012-12-08 22:02:59','ben','',11),(30,'2012-12-08 22:12:22','ben','',12),(31,'2012-12-08 22:13:34','ben','',11),(32,'2012-12-08 22:27:31','ben','',11),(33,'2012-12-08 22:27:39','ben','20',5),(34,'2012-12-08 22:56:46','ben','',11),(35,'2012-12-08 22:56:50','ben','',12),(36,'2012-12-08 22:57:46','ben','',11),(37,'2012-12-08 22:57:50','ben','',12),(38,'2012-12-08 22:57:58','ben','',11),(39,'2012-12-08 22:58:24','ben','',12),(40,'2012-12-08 22:58:38','ben','',11),(41,'2012-12-08 22:59:44','ben','',12),(42,'2012-12-08 23:14:02','ben','',11),(43,'2012-12-09 00:10:50','ben','',11),(44,'2012-12-09 00:11:01','ben','21',3),(45,'2012-12-09 00:12:50','ben','13',15),(46,'2012-12-09 13:02:15','ben','',11),(47,'2012-12-09 13:05:04','ben','20',5),(48,'2012-12-09 13:05:06','ben','11',9),(49,'2012-12-10 13:11:45','ben','',11),(50,'2012-12-10 13:17:16','ben','',11);
/*!40000 ALTER TABLE `Audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cred`
--

DROP TABLE IF EXISTS `Cred`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cred` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust` int(11) NOT NULL,
  `Added` datetime NOT NULL,
  `Group` int(11) NOT NULL,
  `Hash` blob,
  `CredType` int(11) NOT NULL,
  `Clicky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Address` blob,
  `UName` blob,
  PRIMARY KEY (`id`),
  KEY `idx_Cred_Group` (`Group`),
  KEY `idx_cred_cust` (`cust`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cred`
--

LOCK TABLES `Cred` WRITE;
/*!40000 ALTER TABLE `Cred` DISABLE KEYS */;
INSERT INTO `Cred` VALUES (11,20,'2012-12-08 15:53:10',0,'',12,0,'','PJ3tk+x51XXsSP1twp+03w==');
/*!40000 ALTER TABLE `Cred` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CredTypes`
--

DROP TABLE IF EXISTS `CredTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CredTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CredTypes`
--

LOCK TABLES `CredTypes` WRITE;
/*!40000 ALTER TABLE `CredTypes` DISABLE KEYS */;
INSERT INTO `CredTypes` VALUES (12,'/qm3Fg5R9PZt5u1Ux4zn1w=='),(13,'QRoDsDHBz0zrvZ8QlsuuQw==');
/*!40000 ALTER TABLE `CredTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cust`
--

DROP TABLE IF EXISTS `Cust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  `Group` int(11) NOT NULL,
  `ContactName` blob,
  `ContactSurname` blob,
  `Email` blob,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `idx_Customers` (`Name`(255)),
  KEY `idx_Cust_Group` (`Group`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cust`
--

LOCK TABLES `Cust` WRITE;
/*!40000 ALTER TABLE `Cust` DISABLE KEYS */;
INSERT INTO `Cust` VALUES (20,'Cf/482RS7sM7FlsGWZ5OCg==',0,'2uNIrY1Io47Ga0lLqIdW8A==','2uNIrY1Io47Ga0lLqIdW8A==','2uNIrY1Io47Ga0lLqIdW8A=='),(21,'CJTeqCxsNbeCKF9APcwaCA==',0,'wDvppDh2iFD3OvPjADZWqg==','2uNIrY1Io47Ga0lLqIdW8A==','2uNIrY1Io47Ga0lLqIdW8A==');
/*!40000 ALTER TABLE `Cust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FailedLogins`
--

DROP TABLE IF EXISTS `FailedLogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FailedLogins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `FailedAttempts` int(11) NOT NULL,
  `LastAttempt` datetime NOT NULL,
  `FailedIP` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_failed_user_ip` (`username`,`FailedIP`),
  KEY `idx_failedips` (`FailedIP`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FailedLogins`
--

LOCK TABLES `FailedLogins` WRITE;
/*!40000 ALTER TABLE `FailedLogins` DISABLE KEYS */;
/*!40000 ALTER TABLE `FailedLogins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Groups`
--

DROP TABLE IF EXISTS `Groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Groups`
--

LOCK TABLES `Groups` WRITE;
/*!40000 ALTER TABLE `Groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `Groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sessions`
--

DROP TABLE IF EXISTS `Sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sessions` (
  `SessionID` varchar(150) NOT NULL,
  `Created` datetime NOT NULL,
  `User` varchar(150) NOT NULL,
  `Expires` datetime NOT NULL,
  `ClientIP` varchar(100) NOT NULL,
  `SessKey` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`SessionID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sessions`
--

LOCK TABLES `Sessions` WRITE;
/*!40000 ALTER TABLE `Sessions` DISABLE KEYS */;
INSERT INTO `Sessions` VALUES ('57f3f34041af80bc90d9764ab1f78ccf','2012-12-09 13:02:15','ben','2012-12-09 13:17:15','192.168.1.74','b4182bff4b3cf75f9e54f4990f9bd153c0c2973c'),('a3ffd6f9a42ad188064f48d5de6f785c','2012-12-09 00:10:50','ben','2012-12-09 00:25:50','192.168.1.74','5c8f5ac0b7ad23c110793ad1fcf4d3c8d41344d5'),('cf3b270cf311f1c00a54c888d36ca867','2012-12-10 13:11:45','ben','2012-12-10 13:26:45','127.0.0.1','934385f53d1bd0c1b8493e44d0dfd4c8e88a04bb'),('a459d9001535eaa809d794012e853db2','2012-12-10 13:17:16','ben','2012-12-10 13:32:16','127.0.0.1','49e3d046636e06b2d82ee046db8e6eb9a2e11e16');
/*!40000 ALTER TABLE `Sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `username` varchar(150) NOT NULL,
  `pass` blob NOT NULL,
  `Name` varchar(255) NOT NULL,
  `membergroup` longtext,
  `Usergroup` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`,`Usergroup`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES ('ben','bMk5fMswJQ0EsnEW5Ax3w+BWAuvmOuoSqirEa4Gxwa8ws2Mz7PYPZ0TRmiYtRliOLzYjt1w9TMQVLb52w2JdZfXLSFOHlFxneVgjc4s3Toc=','B Tasker','-1',0);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bannedIPs`
--

DROP TABLE IF EXISTS `bannedIPs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bannedIPs` (
  `IP` varchar(255) NOT NULL,
  `Expiry` datetime NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `idx_ban_expiry` (`Expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bannedIPs`
--

LOCK TABLES `bannedIPs` WRITE;
/*!40000 ALTER TABLE `bannedIPs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bannedIPs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Audit`
--

DROP TABLE IF EXISTS `pbku_Audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `User` varchar(150) DEFAULT NULL,
  `Cust` varchar(150) DEFAULT NULL,
  `Action` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Audit`
--

LOCK TABLES `pbku_Audit` WRITE;
/*!40000 ALTER TABLE `pbku_Audit` DISABLE KEYS */;
INSERT INTO `pbku_Audit` VALUES (1,'2012-12-10 13:39:29','ben','',11),(2,'2012-12-10 13:40:33','ben','',11),(3,'2012-12-10 13:42:55','ben','',11);
/*!40000 ALTER TABLE `pbku_Audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Cred`
--

DROP TABLE IF EXISTS `pbku_Cred`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Cred` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust` int(11) NOT NULL,
  `Added` datetime NOT NULL,
  `Group` int(11) NOT NULL,
  `Hash` blob,
  `CredType` int(11) NOT NULL,
  `Clicky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Address` blob,
  `UName` blob,
  PRIMARY KEY (`id`),
  KEY `idx_Cred_Group` (`Group`),
  KEY `idx_cred_cust` (`cust`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Cred`
--

LOCK TABLES `pbku_Cred` WRITE;
/*!40000 ALTER TABLE `pbku_Cred` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_Cred` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_CredTypes`
--

DROP TABLE IF EXISTS `pbku_CredTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_CredTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_CredTypes`
--

LOCK TABLES `pbku_CredTypes` WRITE;
/*!40000 ALTER TABLE `pbku_CredTypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_CredTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Cust`
--

DROP TABLE IF EXISTS `pbku_Cust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Cust` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  `Group` int(11) NOT NULL,
  `ContactName` blob,
  `ContactSurname` blob,
  `Email` blob,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `idx_Customers` (`Name`(255)),
  KEY `idx_Cust_Group` (`Group`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Cust`
--

LOCK TABLES `pbku_Cust` WRITE;
/*!40000 ALTER TABLE `pbku_Cust` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_Cust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_FailedLogins`
--

DROP TABLE IF EXISTS `pbku_FailedLogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_FailedLogins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `FailedAttempts` int(11) NOT NULL,
  `LastAttempt` datetime NOT NULL,
  `FailedIP` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_failed_user_ip` (`username`,`FailedIP`),
  KEY `idx_failedips` (`FailedIP`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_FailedLogins`
--

LOCK TABLES `pbku_FailedLogins` WRITE;
/*!40000 ALTER TABLE `pbku_FailedLogins` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_FailedLogins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Groups`
--

DROP TABLE IF EXISTS `pbku_Groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Groups`
--

LOCK TABLES `pbku_Groups` WRITE;
/*!40000 ALTER TABLE `pbku_Groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_Groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Sessions`
--

DROP TABLE IF EXISTS `pbku_Sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Sessions` (
  `SessionID` varchar(150) NOT NULL,
  `Created` datetime NOT NULL,
  `User` varchar(150) NOT NULL,
  `Expires` datetime NOT NULL,
  `ClientIP` varchar(100) NOT NULL,
  `SessKey` varchar(255) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  PRIMARY KEY (`SessionID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Sessions`
--

LOCK TABLES `pbku_Sessions` WRITE;
/*!40000 ALTER TABLE `pbku_Sessions` DISABLE KEYS */;
INSERT INTO `pbku_Sessions` VALUES ('e68e73004fa0dad2acccbfedf6ba0b71','2012-12-10 13:39:29','ben','2012-12-10 13:54:29','127.0.0.1','c837307a9a2ad4d08ca61a4f1bd848ba3d6890fc'),('16d2f0aed7857d4ca10ee774e339d1d6','2012-12-10 13:40:33','ben','2012-12-10 13:55:33','127.0.0.1','9a15f42d1c524c306eb91c3df1216db248a8f224'),('61206faca316d55c5cdeb0331bd8916f','2012-12-10 13:42:55','ben','2012-12-10 13:57:55','127.0.0.1','d094700e379f0fb3b543e25c77f8e4b3e068f057');
/*!40000 ALTER TABLE `pbku_Sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_Users`
--

DROP TABLE IF EXISTS `pbku_Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_Users` (
  `username` varchar(150) NOT NULL,
  `pass` blob NOT NULL,
  `Name` varchar(255) NOT NULL,
  `membergroup` longtext,
  `Usergroup` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`,`Usergroup`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_Users`
--

LOCK TABLES `pbku_Users` WRITE;
/*!40000 ALTER TABLE `pbku_Users` DISABLE KEYS */;
INSERT INTO `pbku_Users` VALUES ('ben','68fS5BhwSNenZEK5lpJpmQYrhs6TbMEunDMZEuXHWAlwQuS/vxAfQ3vkxeTGS8LHuQHkqtsE9oFkyHqoXle8dhYqfPzB94rbFtUyiKqRh8o=','B Tasker','-1',0);
/*!40000 ALTER TABLE `pbku_Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pbku_bannedIPs`
--

DROP TABLE IF EXISTS `pbku_bannedIPs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbku_bannedIPs` (
  `IP` varchar(255) NOT NULL,
  `Expiry` datetime NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `idx_ban_expiry` (`Expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pbku_bannedIPs`
--

LOCK TABLES `pbku_bannedIPs` WRITE;
/*!40000 ALTER TABLE `pbku_bannedIPs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pbku_bannedIPs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'VirCreds'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-12-10 13:51:09
