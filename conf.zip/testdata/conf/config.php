<?php
/** System Configuration
*
* Copyright (C) 2012 B Tasker
* Released under GNU GPL V2
* See LICENSE
*
*/
defined('_CREDLOCK') or die;

$conf->template = 'EstDeus';
$conf->ProgName = 'PHPCredLocker';
$conf->CredDisplay = '30';
$conf->minpassStrength = '24-35';
$conf->sessionexpiry = '15';
$conf->loggingenabled = 'true';
$conf->forceSSL = false;
$conf->SSLURL = 'https://127.0.0.1/virCreds/Git/Test';
$conf->cronPass = 'a3lbrv223';
$conf->banThresh = '4';
$conf->banProximity = '24';
$conf->banLength = '24';
$conf->dbhost = 'localhost';
$conf->dbname = 'VirCreds';
$conf->dbuser = 'root';
$conf->dbpass = 'Password12';
$conf->tblprefix = 'pbku_';


?>
