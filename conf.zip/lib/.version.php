<?php
/** API call Handler
*
* Copyright (C) 2012 B Tasker
* Released under GNU GPL V2
* See LICENSE
*
*/
defined('_CREDLOCK') or die;





$versionmaj = "1.0";
$versionmin = "1";
$status = "b";

?>