<?php
/** API call Handler
*
* Copyright (C) 2012 B Tasker
* Released under GNU GPL V2
* See LICENSE
*
*/
defined('_BTFrameWork') or die;





$versionmaj = "1.0";
$versionmin = "5";
$status = "";

?>