<?php
/** Auto Auth plugin Config
*
* Copyright (C) 2012 B Tasker
* Released under GNU GPL V2
* See LICENSE
*
*/
defined('_CREDLOCK') or die;

// Set this to false to disable the plugin
$this->active = false;

// Show a JS warning when the user clicks the button. Set to False to disable
$this->warnredirect = true;

?>