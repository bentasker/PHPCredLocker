<?php
/** Plugins Configuration
*
* Copyright (C) 2012 B Tasker
* Released under GNU GPL V2
* See LICENSE
*
*/ 
defined('_CREDLOCK') or die;




$plugins->Auth = array();
$plugins->Logging = array('AffinityLive');
$plugins->Customers = array();
$plugins->Creds = array();
$plugins->Cron = array();

defined("CREDLOCK_PLUGIN__PATH") or define('CREDLOCK_PLUGIN__PATH','plugins/ACDK89345u3Bcd');
